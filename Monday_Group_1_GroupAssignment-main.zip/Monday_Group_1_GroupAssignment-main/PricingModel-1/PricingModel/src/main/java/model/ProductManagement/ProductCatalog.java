/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.ProductManagement;

import java.util.ArrayList;
import model.Supplier.Supplier;

/**
 *
 * @author krish
 */
public class ProductCatalog {

    String type;
    ArrayList<Product> products; //list of products initially empty

    public ProductCatalog(String n) {
        type = n;
         products = new ArrayList();  ///create the list of elements otherwise it is null
         initializeData();
    }
    
    
// new ProductCatalog(); or new ProductCatalog("Printers");
    public ProductCatalog(    ) {
        type = "unknown";
        products = new ArrayList();
    }
    
    private void initializeData() {
         // Product 1
        Product product1 = new Product("Mouse", 600, 500, 600);
        products.add(product1);

        // Product 2
        Product product2 = new Product("Keyboard", 600, 500, 600);
        products.add(product2);

        // Product 3
        Product product3 = new Product("Monitor", 700, 600, 700);
        products.add(product3);

        // Product 4
        Product product4 = new Product("Laptop", 1500, 1200, 1500);
        products.add(product4);

        // Product 5
        Product product5 = new Product("Printer", 800, 700, 800);
        products.add(product5);

        // Product 6
        Product product6 = new Product("Scanner", 400, 300, 400);
        products.add(product6);

        // Product 7
        Product product7 = new Product("Headphones", 300, 250, 300);
        products.add(product7);

        // Product 8 
        Product product8 = new Product("Speakers", 500, 400, 500);
        products.add(product8);

        // Product 9
        Product product9 = new Product("Webcam", 400, 350, 400);
        products.add(product9);

        // Product 10
        Product product10 = new Product("External Hard Drive", 800, 600, 800);
        products.add(product10);
        
    }
    public Product newProduct(int fp, int cp, int tp) {
        Product p = new Product(fp, cp, tp);
        products.add(p);
        return p;
    }
    public Product newProduct(String n, int fp, int cp, int tp) {
        Product p = new Product(n,fp, cp, tp);
        products.add(p);
        return p;
    }

    public ProductsReport generatProductPerformanceReport() {
        ProductsReport productsreport = new ProductsReport();

        for (Product p : products) {

            ProductSummary ps = new ProductSummary(p);
            productsreport.addProductSummary(ps);
        }
        return productsreport;
    }

    public ArrayList<Product> getProductList(){
        return products;
    }
    
    public void removeProduct(Product p) {
        products.remove(p);
    }
    

}

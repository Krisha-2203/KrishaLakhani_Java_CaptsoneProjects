/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Business;

import java.util.ArrayList;
import java.util.Random;
import model.Business.Business;
import model.CustomerManagement.CustomerDirectory;
import model.CustomerManagement.CustomerProfile;
import model.MarketingManagement.MarketingPersonDirectory;
import model.MarketingManagement.MarketingPersonProfile;
import model.OrderManagement.MasterOrderList;
import model.OrderManagement.Order;
import model.OrderManagement.OrderItem;
import model.Personnel.EmployeeDirectory;
import model.Personnel.EmployeeProfile;
import model.Personnel.Person;
import model.Personnel.PersonDirectory;
import model.ProductManagement.Product;
import model.ProductManagement.ProductCatalog;
import model.SalesManagement.SalesPersonDirectory;
import model.SalesManagement.SalesPersonProfile;
import model.Supplier.Supplier;
import model.Supplier.SupplierDirectory;
import model.UserAccountManagement.UserAccount;
import model.UserAccountManagement.UserAccountDirectory;

/**
 *
 * @author suveenasave
 */
public class ConfigureABusiness {
    static String[] names = {
           "Aarav", "Ishita", "Dhruv", "Sanya", "Arjun",         
        "Lakshmi", "Rohan", "Nisha", "Maya", "Vikram",         
        };
    static String[] lastNames= {
        "Singh", "Patel", "Sharma", "Nair", "Gupta",         
        "Menon", "Reddy", "Chaudhary", "Rao", "Mishra",        
        };
    
    static String[] productNames = {
        "DataSync", "CloudSync", "CodeStream", "SecureHub", "InfoGuard",        
        "NetSecure", "EncryptMaster", "DataSphere", "InfoLock", "CodeShield"
    };
    public static Business initialize() {
        Random random = new Random();
        Business business = new Business("Xerox");

        SupplierDirectory supplierDirectory = business.getSupplierDirectory();
        for(int i=0;i<5;i++){
            Supplier supplier=supplierDirectory.newSupplier(getRandomName());
            ProductCatalog productCatalog=supplier.getProductCatalog();
            for(int j=0;j<10;j++){
                int fp = random.nextInt(4001) + 1000; // Floor (between 1000 and 5000)
                int cp = random.nextInt(5001) + 5000; // Ceiling (between 5000 and 10000)
                int tp = random.nextInt(cp - fp + 1) + fp; // Target between floor and ceiling
                Product product = productCatalog.newProduct(getRandomProductName(), fp, cp, tp);
            }
        }
        
        CustomerDirectory customerDirectory = business.getCustomerDirectory();
        MasterOrderList masterOrderList = business.getMasterOrderList();
//        for(int i=0;i<10;i++){
//            Person person = new Person(String.valueOf(random.nextInt(90000) + 10000));
//            CustomerProfile customerProfile = customerDirectory.newCustomerProfile(person);
//            for(int j=0;j<10;j++){
//                Order order = masterOrderList.newOrder(customerProfile);
//                Product product = getRandomProduct(supplierDirectory);
//                int actualPrice = random.nextInt(product.getCeilingPrice() - product.getFloorPrice() + 1) + product.getFloorPrice();
//                order.newOrderItem(product, actualPrice, random.nextInt(91)+10);
////                int newTP = newTargetPrice(product);
////                product.updateProduct(product.getFloorPrice(), product.getCeilingPrice(), newTP);
//            }
//            System.out.println("CustomerProfile: "+customerProfile.getCustomerId());
//        }

for (int i = 0; i < 10; i++) {
    Person person = new Person(String.valueOf(random.nextInt(90000) + 10000));
    CustomerProfile customerProfile = customerDirectory.newCustomerProfile(person);
    
    for (int j = 0; j < 10; j++) {
        Order order = masterOrderList.newOrder(customerProfile);
        
        // Ensure we get a product with a valid price range
        Product product = getRandomProduct(supplierDirectory);
        int floorPrice = product.getFloorPrice();
        int ceilingPrice = product.getCeilingPrice();

        // Ensure positive, valid price range
        if (floorPrice <= 0 || ceilingPrice <= 0 || ceilingPrice <= floorPrice) {
            floorPrice = random.nextInt(50) + 10; // Random positive floor price between 10 and 59
            ceilingPrice = floorPrice + random.nextInt(100) + 20; // Random positive ceiling price above floorPrice
            product.updateProduct(floorPrice, ceilingPrice, (floorPrice + ceilingPrice) / 2);
        }

        // Generate an actual price within the valid range
        int actualPrice = random.nextInt(ceilingPrice - floorPrice + 1) + floorPrice;
        order.newOrderItem(product, actualPrice, random.nextInt(91) + 10);
    }
    
    System.out.println("CustomerProfile: " + customerProfile.getCustomerId());
}
        
        SalesPersonDirectory salesPersonDirectory = business.getSalesPersonDirectory();
        UserAccountDirectory userAccountDirectory = business.getUserAccountDirectory();
        for(int i=0;i<5;i++){
            Person person = new Person(String.valueOf(random.nextInt(90000) + 10000));
            SalesPersonProfile salesPersonProfile = salesPersonDirectory.newSalesPersonProfile(person);
            userAccountDirectory.newUserAccount(salesPersonProfile, salesPersonProfile.getPerson().getPersonId(), "password");
            System.out.println("Sales Person ID: "+salesPersonProfile.getPerson().getPersonId());

        }
        
        return business;
    }
    
    public static String getRandomName() {
        Random random = new Random();
        int randomIndex1 = random.nextInt(names.length);
        int randomIndex2 = random.nextInt(lastNames.length);
        return names[randomIndex1]+" "+lastNames[randomIndex2];
    }
    
    public static String getRandomProductName(){
        Random random = new Random();
        int randomIndex = random.nextInt(productNames.length);
        return productNames[randomIndex];
    }
    
    public static Supplier getRandomSupplier(SupplierDirectory sd) {
        Random random = new Random();
        int index = random.nextInt(sd.getSuplierList().size());
        return sd.getSuplierList().get(index);
    }
    
    
    public static Product getRandomProduct(SupplierDirectory supplierDirectory) {
        Random random = new Random();
        // Get a random supplier from the supplier directory
        Supplier randomSupplier = getRandomSupplier(supplierDirectory);
        // Get the product catalog of the random supplier
        ProductCatalog productCatalog = randomSupplier.getProductCatalog();
        // Get a random product from the product catalog
        int index = random.nextInt(productCatalog.getProductList().size());
        return productCatalog.getProductList().get(index);
    }
}

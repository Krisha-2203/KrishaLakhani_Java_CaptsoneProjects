/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Supplier;

import java.util.ArrayList;

/**
 *
 * @author krish
 */
public class SupplierDirectory {
    ArrayList<Supplier> suppliers;
    public SupplierDirectory(){
        this.suppliers = new ArrayList();
        initializeData();
        
    }
   
    private void initializeData() {
        Supplier supplier1 = new Supplier("HP");
        suppliers.add(supplier1);
        
        Supplier supplier2 = new Supplier("Lenovo");
        suppliers.add(supplier2);
        
        Supplier supplier3 = new Supplier("Dell");
        suppliers.add(supplier3);
        
        Supplier supplier4 = new Supplier("Asus");
        suppliers.add(supplier4);
        
        Supplier supplier5 = new Supplier("Acer");
        suppliers.add(supplier5);
    
        
    }
    public Supplier newSupplier(String n){
        Supplier supplier = new Supplier(n);
        suppliers.add(supplier);
        return supplier;

    }
    public Supplier findSupplier(String id){
        
        for (Supplier supplier: suppliers){
            
            if(supplier.getName().equals(id)) return supplier;
        }
        return null;
        }

    public ArrayList<Supplier> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(ArrayList<Supplier> suppliers) {
        this.suppliers = suppliers;
    }
    
       public ArrayList<Supplier> getSuplierList(){
        return suppliers;
    }
    
    public void removeSupplier(Supplier s) {
        suppliers.remove(s);
    }
    
}